package Workfiles;

import javax.persistence.*;

@Entity
@Table(name = "OPERATORS")
@PrimaryKeyJoinColumn(name = "OPERATOR_ID")
public class Operator extends Employee {

    public Operator(Company company) {
        setCompany(company);
        monthSalary = getMonthSalary();
    }

    @Override
    public double getMonthSalary() {
        return 30000.;
    }

}
