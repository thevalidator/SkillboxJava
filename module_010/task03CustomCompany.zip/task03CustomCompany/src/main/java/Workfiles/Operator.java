package Workfiles;

import com.sun.istack.NotNull;

import javax.persistence.*;

@Entity
@PrimaryKeyJoinColumn(name = "OPERATOR_ID")
public class Operator extends Employee {

    @NotNull
    @Transient
    private Company company;

    public Operator(Company company) {
        this.company = company;
    }

    @Column(name = "month_salary")
    @Override
    public double getMonthSalary() {
        return 30000.;
    }
}
