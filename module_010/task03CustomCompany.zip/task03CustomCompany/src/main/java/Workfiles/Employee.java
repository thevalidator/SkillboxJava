package Workfiles;

import javax.persistence.*;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;

    public abstract double getMonthSalary();

    public double getSalesAmount() {
        return 0;
    }

}
