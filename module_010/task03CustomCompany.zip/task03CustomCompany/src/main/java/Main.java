import Workfiles.Company;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;


public class Main {

    static SessionFactory sessionFactory;

    public static void main(String[] args) {

        final Logger LOG = LogManager.getLogger("trace");

        /*String topManager = "topManager";
        String manager = "manager";
        String operator = "operator";

        int num = 2;
        Company drova = new Company();
        Company roga = new Company();
        Company kopyta = new Company();

        drova.setCompanyName("DROVA");
        roga.setCompanyName("ROGA");
        kopyta.setCompanyName("KOPYTA");

        drova.hire(manager);
        drova.hire(topManager);

        roga.hire(manager);
        roga.hire(operator);
        roga.hire(topManager);

        kopyta.hireAll();

        System.out.println(drova.getCompanyIncome());
        System.out.println(drova.employeeList.size());
        System.out.println(drova.employeeList.get(0).getMonthSalary());
        drova.getLowSalaryStaff(num);
        drova.getTopSalaryStaff(num);

        roga.getLowSalaryStaff(num);
        roga.getTopSalaryStaff(num);

        kopyta.getTopSalaryStaff(15);
        roga.getTopSalaryStaff(2);

        System.out.println(drova.getCompanyIncome());
        System.out.println(roga.getCompanyIncome());
        System.out.println(kopyta.getCompanyIncome());*/


        Session session = null;
        Transaction transaction = null;
        try {
            StandardServiceRegistry registry = new StandardServiceRegistryBuilder().configure().build();
            Metadata metadata = new MetadataSources(registry).getMetadataBuilder().build();
            sessionFactory = metadata.getSessionFactoryBuilder().build();
            session = sessionFactory.openSession();
            transaction = session.beginTransaction();

            Company kamaz = new Company();
            LOG.trace("New company created. ID: " + kamaz.getId() + " Name:" + kamaz.getCompanyName());
            kamaz.setCompanyName("KAMAZ");
            LOG.trace(kamaz.getId() + " Name:" + kamaz.getCompanyName());
            Company drova = new Company();
            drova.setCompanyName("DROVA");

            Company roga = new Company();
            roga.setCompanyName("ROGA");
            Company kopyta = new Company();
            kopyta.setCompanyName("KOPYTA");

            kamaz.hire("operator");
            LOG.trace(kamaz.getEmployeeList().size());
            System.out.println(kamaz.getEmployeeList().get(0).getMonthSalary());

            session.save(kamaz);
            session.save(kamaz.getEmployeeList().get(0));

            

            transaction.commit();
            session.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            sessionFactory.close();
        }
    }
}
